def secret_function():
    print('My username is lielamar and I know I must read the submission response.')